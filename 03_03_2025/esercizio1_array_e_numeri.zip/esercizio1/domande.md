# Esercizio: Operazioni su Array di Numeri
Sviluppa un programma C modulare che permetta di eseguire diverse operazioni su array di numeri interi.
Funzionalità richieste:

- Stampa dell'array
- Calcolo della somma degli elementi
- Calcolo della media
- Trovare il valore massimo e minimo