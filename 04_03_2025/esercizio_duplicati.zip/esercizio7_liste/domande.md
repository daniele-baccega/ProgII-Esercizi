# Esercizio 5 - Rimozione duplicati da lista linkata (lista non ordinata)

Scrivere una funzione `rimuovi_duplicati` che riceve una lista linkata non ordinata e rimuove tutti i nodi contenenti valori duplicati. Dopo l'es
