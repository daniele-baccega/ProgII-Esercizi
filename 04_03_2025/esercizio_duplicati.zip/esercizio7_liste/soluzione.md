# Soluzione Esercizio 5 - Comandi

#Per compilare:

gcc -o esercizio_duplicati soluzione/src/main.c soluzione/src/lista.c -Isoluzione/include


#per eseguire

./esercizio5